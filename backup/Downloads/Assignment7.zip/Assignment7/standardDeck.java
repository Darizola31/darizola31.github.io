//standardDeck.java
import java.util.*;
import java.lang.*;

public class standardDeck implements IDeck
{

      private ArrayList<PlayingCard> cards;
      
      public standardDeck()
      {
        int i=0;
        int j=0;
        
             //Loops to add all of the cards to the deck.
        for (i = 0; i <13; i++){
          
          for( j = 0; j < 4; j++){
             cards.add(new PlayingCard(suitToString(i), rankToString(j)));
          }
        }
             
             
             shuffle();
      }
      
   public void reset()
     //Put all the cards back in the arrayList and then shuffle.
     //this should be a call back to >public StandardDeck<
         {
        int i=0;
        int j=0;
        
             //Loops to add all of the cards to the deck.
        for (i = 0; i <13; i++){
          
          for( j = 0; j < 4; j++){
             cards.add(new PlayingCard(suitToString(i), rankToString(j)));
          }
        }
           
         shuffle();
         }

   public void shuffle()
   {
      Collections.shuffle(cards);
   }

   public IPlayingCard drawTopCard()
   {
      //draw the top card.
      PlayingCard aCard = cards.get(0);

      //remove it from arrayList
      cards.remove(0);
      //return card.
      return aCard;
   }


   private String rankToString(int numberRank)
    {
     String Stringsuit = "";
     
      switch (numberRank) {
            case 1:  Stringsuit = "ACE";
                     break;
            case 2:  Stringsuit = "DEUCE";
                     break;
            case 3:  Stringsuit = "TREY";
                     break;
            case 4:  Stringsuit = "4";
                     break;
            case 5:  Stringsuit = "5";
                     break;
            case 6:  Stringsuit = "6";
                     break;
            case 7:  Stringsuit = "7";
                     break;
            case 8:  Stringsuit = "8";
                     break;
            case 9:  Stringsuit = "9";
                     break;
            case 10: Stringsuit = "10";
                     break;
            case 11: Stringsuit = "JACK";
                     break;
            case 12: Stringsuit = "QUEEN";
                     break;
            case 13: Stringsuit = "KING";
                     break;
            default: Stringsuit = "POOP";
                     break;
        }
    return Stringsuit;
    }
    private String suitToString(int rankNumber)
    {
      String rank = "";
         switch (rankNumber) {
            case 1:  rank = "HEARTS";
                     break;
            case 2:  rank = "DIAMONDS";
                     break;
            case 3:  rank = "CLUBS";
                     break;
            case 4:  rank = "SPADES";
                     break;
            default: rank = "MAN";
                     break;

         }
    return rank;
    }
}