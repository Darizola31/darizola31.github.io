import java.util.*;
import java.lang.*;
//Class Description
public class IPlayingCard implements PlayingCard
{
        String suit;
        String rank;
       
 //Constructor   
    public PlayingCard()
    {
     rank = "ACE";
     suit = "HEARTS";
    }
    //constructor for the instantiation
    public PlayingCard(String aSuit, String aRank)
    {
      suit = aSuit;
      rank = aRank;
    }
        
        
        
    public boolean equals(PlayingCard cardB )
    {
       return (cardB.suit == suit) && (cardB.rank == rank);
    }


    public String getSuit(){
      return suit;
    }
    public String getRank(){
      return rank;
    }
    

   public int compareTo(Object other)
   {

      IPlayingCard otherCard = (PlayingCard) other;


      //If suits are the same, compare the ranks.
      if (suit.equals(otherCard.getSuit()))
      {
        ///if ranks are the same pass as such...
        if (rank.equals(otherCard.getRank()))
          return 0;
          
        else
        {
          //return -1 if rank is less.
          //return 1 if rank is greater.
        }
      }
      //else return -1 or 1 based on the value of the suit strings.
      else
      {
          return suit.compareTo(otherCard.getSuit());
      }
          ///...but if ranks are not the same return a non zero value
          return 1;
   }


    private String rankToString(int numberRank)
    {
      switch (numberRank) {
            case 1:  suit = "ACE";
                     break;
            case 2:  suit = "DEUCE";
                     break;
            case 3:  suit = "TREY";
                     break;
            case 4:  suit = "4";
                     break;
            case 5:  suit = "5";
                     break;
            case 6:  suit = "6";
                     break;
            case 7:  suit = "7";
                     break;
            case 8:  suit = "8";
                     break;
            case 9:  suit = "9";
                     break;
            case 10: suit = "10";
                     break;
            case 11: suit = "JACK";
                     break;
            case 12: suit = "QUEEN";
                     break;
            case 13: suit = "KING";
                     break;
            default: suit = "POOP";
                     break;
        }
                 return suit;
    }
    private String suitToString(int rankNumber)
    {
         switch (rankNumber) {
            case 1:  rank = "HEARTS";
                     break;
            case 2:  rank = "DIAMONDS";
                     break;
            case 3:  rank = "CLUBS";
                     break;
            case 4:  rank = "SPADES";
                     break;
            default: rank = "MAN";
                     break;

         }             
         return rank;
    
    }
    public String toString()

    {

        return suit + " of " + rank;

    }
}