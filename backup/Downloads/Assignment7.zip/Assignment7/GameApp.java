
public class GameApp
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        GameFrame aBoard = new GameFrame();
        
        aBoard.setVisible(true);

    }

}
