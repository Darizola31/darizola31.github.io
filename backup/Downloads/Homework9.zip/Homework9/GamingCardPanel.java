import java.awt.*;
import javax.swing.*;


/**
 * The DiePanel class draws the image of a die.
 *
 * @author Michael J. Holmes
 * @version 1.0 Dec 17, 2012.
 * Modified by D.Arizola 
 */

public class GamingCardPanel extends JPanel
{


 //----------------------------------------------------------------------------------
    // Instance Variables
 //----------------------------------------------------------------------------------
    private IPlayingCard myCard;
    private PlayingDeck myDeck;

 //----------------------------------------------------------------------------------
    // Constructors
 //----------------------------------------------------------------------------------

    /**
     * Default constructor creates a white die.
     */
    public GamingCardPanel()
    {
        myCard = new PlayingCard();
        myDeck = new PlayingDeck();

        this.setBackground(Color.white);
        this.setPreferredSize(new Dimension(100,200));
    }


    //----------------------------------------------------------------------------------
    //Class Methods
    //----------------------------------------------------------------------------------
    /**
     * Rolls the die and repaints the display to the new result.
     */
    public void resetCard()
    {
       repaint();
    }
    public void reset(){
      myDeck.reset();
      
    }

    /**
     * Defines how this object is drawn on the screen.
     *
     * @param g The Graphics object to draw to.
     */
    public void paintComponent(Graphics g)
    {
     // Required to draw the panel.
        super.paintComponent(g);

        // Initialize local variables.
        int panelWidth = this.getWidth();
        int panelHeight = this.getHeight();

        // Draw the outside border of card.
        g.drawRoundRect(0, 0, panelWidth-1, panelHeight-1, 1, 1);

        //draw card name
        g.drawString(myCard.getSuit(), 20, 90);
        g.drawString(myCard.getRank(), 20, 110);

        switch (myCard.getSuit()) {
          case "DIAMONDS": setBackground(Color.red);
                 setForeground(Color.white);
                 repaint();
                     break;
          case "HEARTS": setBackground(Color.red);
                 setForeground(Color.white);
                 repaint();
                     break;
          case "CLUBS": setBackground(Color.black);
                 setForeground(Color.white);
                 repaint();
                     break;
          case "SPADES": setBackground(Color.black);
                 setForeground(Color.white);
                 repaint();
                     break;
          case "WILD": setBackground(Color.black);
                 setForeground(Color.white);
                 repaint();
                 break;
          default: setBackground(Color.white);
                   setForeground(Color.black);
                 repaint();
          break;
        }
                     
    }


    public void getNext()
    {
      


      myCard = myDeck.drawTopCard();
      repaint();
    }



    //----------------------------------------------------------------------------------
    // Private Helper Methods
    //----------------------------------------------------------------------------------

    /**
     * Defines how this object is drawn on the screen.
     *
     * @param g The Graphics object to draw to.
     * @param numberOfPips the number of pips to draw on the die.
     */
    private void FaceValue(PlayingCard s)
    {
     //Initialize local variables.
        int panelWidth = this.getWidth();
        int panelHeight = this.getHeight();

        //brings in the Face Value of the cards.
        System.out.println(s.toString());
    }

}