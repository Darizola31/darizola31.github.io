import java.util.*;
import java.lang.*;
import java.io.*;

public class PlayingDeck implements IDeck
{

      private ArrayList<PlayingCard> cards;
      private ArrayList<PlayingCard> resetCards;

     public PlayingDeck()
      {
               
       Scanner fileIn;
       String line;
       String[] values;
       String pCRank;
       String pCSuit;
        
        cards = new ArrayList<PlayingCard>();
        resetCards = new ArrayList<PlayingCard>();

       //Loops to add all of the cards to the deck.
  try
  {
     // Open File 
     fileIn = new Scanner(new FileInputStream("C:\\Users\\velo\\Desktop\\Homework8\\Homework9\\Euchre_Deck.txt"));
    
     // Read from File  
     while ( fileIn.hasNext())
     {
    line = fileIn.nextLine();
    values = line.split(",");
    cards.add(new PlayingCard(suitToString(values[1]), rankToString(values[0])));
    resetCards.add(new PlayingCard(suitToString(values[1]), rankToString(values[0])));
     }  
  
     // Close File
     fileIn.close();
  
  
  }
  catch (FileNotFoundException e)
  {
   System.out.println("File doesn't exist!");
  }
 
             shuffle();
     }
     public void reset(){
     //Put all the cards back in the arrayList and then shuffle.
     //this should be a call back to >public PlayingCardDeck<

       this.cards = new ArrayList<PlayingCard>(resetCards);
       shuffle();
         }

   public void shuffle()
   {
      Collections.shuffle(cards);
   }

   public IPlayingCard drawTopCard() throws OutOfCardsException
   {


     if (cards.size() == 0)
     {
       throw new OutOfCardsException("The out of cards exception has been triggered!");
     }
     else
     {

      //draw the top card.
      PlayingCard aCard = cards.get(0);

      //remove it from arrayList
      cards.remove(0);

      //return card.
      return aCard;
     }
   }


   private String rankToString(String numberRank)
    {
     String Stringsuit = "";
     
      switch (numberRank) {
            case "Ace":  Stringsuit = "ACE";
                     break;
            case "2":  Stringsuit = "2";
                     break;
            case "3":  Stringsuit = "3";
                     break;
            case "4":  Stringsuit = "4";
                     break;
            case "5":  Stringsuit = "5";
                     break;
            case "6":  Stringsuit = "6";
                     break;
            case "7":  Stringsuit = "7";
                     break;
            case "8":  Stringsuit = "8";
                     break;
            case "9": Stringsuit = "9";
                     break;
            case "10": Stringsuit = "10";
                     break;
            case "Jack": Stringsuit = "JACK";
                     break;
            case "Queen": Stringsuit = "QUEEN";
                     break;
        case "King": Stringsuit = "KING";
        break;    
        default:            
                     break;
        }
    return Stringsuit;
    }
    private String suitToString(String rankNumber)
    {
      String Stringrank = "";
         switch (rankNumber) {
            case "Hearts":  Stringrank = "HEARTS";
                     break;
            case "Diamonds":  Stringrank = "DIAMONDS";
                     break;
            case "Spades":  Stringrank = "SPADES";
                     break;
            default:  Stringrank = "CLUBS";
                     break;
         }
    return Stringrank;
    }
}