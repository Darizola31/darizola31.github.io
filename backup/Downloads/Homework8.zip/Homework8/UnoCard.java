import java.util.*;
import java.lang.*;
//Class Description
public class UnoCard implements IPlayingCard
{
        String suit;
        String rank;
       
 //Constructor   
    public UnoCard()
    {
     rank = "STARTER";
     suit = "NO RANK";
    }
    //constructor for the instantiation
    public UnoCard(String aSuit, String aRank)
    {
      suit = aSuit;
      rank = aRank;
    }
        
        
        
    public boolean equals(UnoCard cardB )
    {
       return (cardB.suit == suit) && (cardB.rank == rank);
    }


    public String getSuit(){
      return suit;
    }
    public String getRank(){
      return rank;
    }
    

   public int compareTo(Object other)
   {

      IPlayingCard otherCard = (UnoCard) other;


      //If suits are the same, compare the ranks.
      if (suit.equals(otherCard.getSuit()))
      {
        ///if ranks are the same pass as such...
        if (rank.equals(otherCard.getRank()))
          return 0;
          
        else
        {
          //return -1 if rank is less.
          //return 1 if rank is greater.
        }
      }
      //else return -1 or 1 based on the value of the suit strings.
      else
      {
          return suit.compareTo(otherCard.getSuit());
      }
          ///...but if ranks are not the same return a non zero value
          return 1;
   }


    private String rankToString(int numberRank)
    {
      switch (numberRank) {
            case 1:  suit = "1";
                     break;
            case 2:  suit = "2";
                     break;
            case 3:  suit = "3";
                     break;
            case 4:  suit = "4";
                     break;
            case 5:  suit = "5";
                     break;
            case 6:  suit = "6";
                     break;
            case 7:  suit = "7";
                     break;
            case 8:  suit = "8";
                     break;
            case 9:  suit = "9";
                     break;
            case 10: suit = "SKIP";
                     break;
            case 11: suit = "DRAW TWO";
                     break;
            case 12: suit = "REVERSE";
                     break;
            default: suit = "WILD";
                     break;
        }
                 return suit;
    }
    private String suitToString(int rankNumber)
    {
         switch (rankNumber) {
            case 1:  rank = "RED";
                     break;
            case 2:  rank = "GREEN";
                     break;
            case 3:  rank = "BLUE";
                     break;
            case 4:  rank = "YELLOW";
                     break;         
            default: rank = "NONE";
                     break;

         }             
         return rank;
    
    }
    public String toString()

    {

        return suit + " of " + rank;

    }
}