
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * The DieFrame class contains a Frame with two dice and a roll button.
 *
 * @author Michael J. Holmes
 * @version 1.0 Dec 17, 2012.
 */
public class GameFrame extends JFrame
{
 //----------------------------------------------------------------------------------
    // Instance Variables
 //----------------------------------------------------------------------------------
    private GamingCardPanel card;
    private JPanel field;
    private JPanel menu;



 //----------------------------------------------------------------------------------
    // Constructors
 //----------------------------------------------------------------------------------
    public GameFrame()
    {
       /**
        * Default constructor.
       */

       // Initialize the frame properties
    this.setLayout(new FlowLayout());
    this.setSize( 500, 300 );
       this.setTitle( "Uno Playing Deck" );


       this.createFieldPanel();
       this.createMenuPanel();


       //Add the field and menu panels to the frame.
       this.add(field);
       this.add(menu);
   }
    


 //----------------------------------------------------------------------------------
    // Class Methods
 //----------------------------------------------------------------------------------






 //----------------------------------------------------------------------------------
    // Private Helpers
 //----------------------------------------------------------------------------------

    /**
     * Build the menu panel.
    */
    private void createMenuPanel()
    {
      //Set up the menu area.
      menu = new JPanel();
      menu.setBounds(0,300,250,100);

      //Create a button and add a listener to it.
      JButton resetButton = new JButton("Reset Deck");
      JButton drawButton = new JButton("Next Card");
      resetButton.setSize(300,200);
      drawButton.setSize(300,200);

      resetButton.addActionListener(new ResetListener());
      drawButton.addActionListener(new NextCardListener());

      //Add the button to the menu area.
      menu.add(resetButton);
      menu.add(drawButton);
    }


    /**
     * Build the field panel.
    */
    private void createFieldPanel()
    {
        //Set up the dice field area.
        field = new JPanel();
        field.setBounds(0,0,250,200);

        //Create the dice and add them.

        card = new GamingCardPanel();

        field.add(card);


    }

       private class NextCardListener implements ActionListener
   {
         
         public void actionPerformed(ActionEvent e){
         try
         {
           card.getNext();
         }
       
       catch(OutOfCardsException exception)
       {
         card.reset();
       }}
   }


   private class ResetListener implements ActionListener
   {
       public void actionPerformed(ActionEvent e)
       {
        card.resetCard();
       }
   }
}