
import java.util.*;
import java.lang.*;

public class UnoDeck implements IDeck
{

      private ArrayList<UnoCard> cards;

     public UnoDeck()
      {
        int i=0;
        int j=0;
        
        cards = new ArrayList<UnoCard>();

             //Loops to add all of the cards to the deck.
        for (j = 0; j <12; j++)
        {
          for( i = 1; i < 5; i++)
          {
             cards.add(new UnoCard(suitToString(i), rankToString(j)));
          }
        }
        for (i = 0; i <12; i++)
        {
          for( j = 0; j < 4; j++)
          {
             cards.add(new UnoCard(suitToString(j), rankToString(i)));
          }

        }
        for (i=0; i < 4; i++)
        {
          cards.add(new UnoCard("WILD", "WILD"));
        }
        for (j =0; j < 4; j++)
        {
          cards.add(new UnoCard("WILD", "DRAW 4!"));
          cards.add(new UnoCard(suitToString(j), "0"));
        }
             shuffle();
      }

   public void reset()
     //Put all the cards back in the arrayList and then shuffle.
     //this should be a call back to >public UnoDeck<
         {
        int i=0;
        int j=0;

             //Loops to add all of the cards to the deck.
        for (i = 0; i <12; i++)
        {
          for( j = 0; j < 4; j++)
          {
             cards.add(new UnoCard(suitToString(j), rankToString(i)));
          }
        }
        for (i = 0; i <12; i++){

          for( j = 0; j < 4; j++){
             cards.add(new UnoCard(suitToString(j), rankToString(i)));
          }

        }
        for (i=0; i< 4; i++){
          cards.add(new UnoCard("WILD", "WILD"));
        }
        for (j =0; j < 4; j++){
          cards.add(new UnoCard("WILD", "DRAW 4!"));
          cards.add(new UnoCard(suitToString(j), "0"));
        }
         shuffle();
         }

   public void shuffle()
   {
      Collections.shuffle(cards);
   }

   public IPlayingCard drawTopCard() throws OutOfCardsException
   {


     if (cards.size() == 0)
     {
       throw new OutOfCardsException("The out of cards exception has been triggered!");
     }
     else
     {

      //draw the top card.
      UnoCard aCard = cards.get(0);

      //remove it from arrayList
      cards.remove(0);

      //return card.
      return aCard;
     }
   }


   private String rankToString(int numberRank)
    {
     String Stringsuit = "";
     
      switch (numberRank) {
            case 1:  Stringsuit = "1";
                     break;
            case 2:  Stringsuit = "2";
                     break;
            case 3:  Stringsuit = "3";
                     break;
            case 4:  Stringsuit = "4";
                     break;
            case 5:  Stringsuit = "5";
                     break;
            case 6:  Stringsuit = "6";
                     break;
            case 7:  Stringsuit = "7";
                     break;
            case 8:  Stringsuit = "8";
                     break;
            case 9: Stringsuit = "9";
                     break;
            case 10: Stringsuit = "SKIP";
                     break;
            case 11: Stringsuit = "DRAW TWO";
                     break;
            case 0: Stringsuit = "REVERSE";
                     break;
            default:            
                     break;
        }
    return Stringsuit;
    }
    private String suitToString(int rankNumber)
    {
      String Stringrank = "";
         switch (rankNumber) {
            case 1:  Stringrank = "RED";
                     break;
            case 2:  Stringrank = "GREEN";
                     break;
            case 3:  Stringrank = "BLUE";
                     break;
            default:  Stringrank = "YELLOW";
                     break;
         }
    return Stringrank;
    }
}