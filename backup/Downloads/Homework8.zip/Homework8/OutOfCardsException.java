import java.util.*;
public class OutOfCardsException extends RuntimeException {
    
    public OutOfCardsException(String astring) {
        super(astring);
    }

}
