public interface IPlayingCard extends Comparable
{
   public String getSuit();
   public String getRank();
}